// components/ui/KpiCard.tsx
// Card de métrica — use em qualquer dashboard
// Exemplo: <KpiCard label="CAC Médio" value="R$142" delta="+8%" trend="up" />

interface KpiCardProps {
  label: string
  value: string
  delta?: string
  trend?: 'up' | 'down' | 'neutral'
  hint?: string  // texto pequeno abaixo do delta, ex: "vs mês anterior"
}

export default function KpiCard({ label, value, delta, trend = 'neutral', hint }: KpiCardProps) {
  const deltaColor =
    trend === 'up'   ? 'text-emerald-600' :
    trend === 'down' ? 'text-red-500' :
    'text-gray-400'

  return (
    <div className="bg-gray-50 rounded-lg p-4 border border-gray-100">
      <p className="text-xs text-gray-400 uppercase tracking-wider mb-2">{label}</p>
      <p className="text-2xl font-medium text-gray-900">{value}</p>
      {delta && (
        <p className={`text-xs mt-1 ${deltaColor}`}>
          {delta} {hint && <span className="text-gray-400">{hint}</span>}
        </p>
      )}
    </div>
  )
}
