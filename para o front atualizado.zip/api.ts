/**
 * Cliente HTTP — conecta ao backend FastAPI (Python).
 * Troque a BASE_URL pelo endereço do seu servidor.
 */

const BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000'

async function fetcher<T>(endpoint: string, params?: Record<string, string>): Promise<T> {
  const url = new URL(`${BASE_URL}${endpoint}`)
  if (params) {
    Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v))
  }

  const res = await fetch(url.toString(), {
    headers: { 'Content-Type': 'application/json' },
    // next: { revalidate: 300 } // revalida cache a cada 5 min (Next.js 14+)
  })

  if (!res.ok) {
    throw new Error(`Erro na API: ${res.status} ${res.statusText}`)
  }

  return res.json()
}

// ── KPIs gerais ──────────────────────────────────────────────
export const getKPIs = (params?: Record<string, string>) =>
  fetcher('/metricas/kpis', params)

// ── CAC por canal ────────────────────────────────────────────
export const getCACPorCanal = (params?: Record<string, string>) =>
  fetcher('/metricas/cac', params)

// ── Campanhas Meta Ads ───────────────────────────────────────
export const getCampanhas = (params?: Record<string, string>) =>
  fetcher('/meta/campanhas', params)

// ── Disparos WhatsApp ────────────────────────────────────────
export const getDisparos = (params?: Record<string, string>) =>
  fetcher('/meta/disparos', params)

// ── Equipe de vendas ─────────────────────────────────────────
export const getVendedores = (params?: Record<string, string>) =>
  fetcher('/vendedores', params)

// ── Funil de aquisição ───────────────────────────────────────
export const getFunil = (params?: Record<string, string>) =>
  fetcher('/funil', params)

// ── Leads por canal ──────────────────────────────────────────
export const getLeadsPorCanal = (params?: Record<string, string>) =>
  fetcher('/leads/por-canal', params)
