# BI Aquisição — Frontend Next.js

## Instalação

```bash
npm install
npm run dev
```

Acesse: http://localhost:3000

---

## Onde mexer em cada coisa

### Quero mudar os dados exibidos
→ `src/lib/mock.ts`
Todos os dados simulados ficam aqui. Edite os valores e a tela atualiza na hora.

### Quero adicionar uma nova métrica nos cards
→ `src/app/page.tsx` (visão geral) ou `src/app/cac/page.tsx` etc.
Cada página tem os cards de KPI. Adicione um `<KpiCard />` a mais.

### Quero mudar o visual de um card de métrica
→ `src/components/ui/KpiCard.tsx`
Um único componente usado em todas as páginas. Mude aqui e reflete em todo lugar.

### Quero adicionar uma nova página
1. Crie a pasta: `src/app/NOME-DA-PAGINA/`
2. Crie o arquivo: `src/app/NOME-DA-PAGINA/page.tsx`
3. Adicione o link na sidebar: `src/components/layout/Sidebar.tsx`

### Quero conectar o backend real (FastAPI)
1. Crie um `.env.local` na raiz:
   ```
   NEXT_PUBLIC_API_URL=http://localhost:8000
   ```
2. Em cada página, substitua o mock pelo fetch real:
   ```typescript
   // Antes (mock)
   const vendedores = mockVendedores

   // Depois (backend real)
   const vendedores = await getVendedores({ inicio: '2024-07-01', fim: '2024-07-31' })
   ```

### Quero adicionar gráficos interativos
Instale o Recharts (já está no package.json):
```bash
npm install recharts
```
Use em qualquer página:
```tsx
import { BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts'
```

---

## Estrutura de pastas

```
src/
├── app/
│   ├── layout.tsx        ← sidebar + estrutura de todas as páginas
│   ├── page.tsx          ← localhost:3000/ (visão geral)
│   ├── cac/page.tsx      ← localhost:3000/cac
│   ├── equipe/page.tsx   ← localhost:3000/equipe
│   └── funil/page.tsx    ← localhost:3000/funil
│
├── components/
│   ├── ui/
│   │   └── KpiCard.tsx   ← card de métrica reutilizável
│   └── layout/
│       └── Sidebar.tsx   ← navegação lateral
│
├── lib/
│   ├── api.ts            ← funções que chamam o backend FastAPI
│   └── mock.ts           ← dados simulados para desenvolvimento
│
└── types/
    └── index.ts          ← tipos TypeScript de todos os dados
```
