'use client'

// components/layout/Sidebar.tsx
// Navegação lateral — aparece em todas as páginas via layout.tsx

import Link from 'next/link'
import { usePathname } from 'next/navigation'

const links = [
  { href: '/',        label: 'Visão geral',        icon: '◈' },
  { href: '/cac',     label: 'CAC & Meta Ads',      icon: '◎' },
  { href: '/equipe',  label: 'Equipe comercial',    icon: '◉' },
  { href: '/funil',   label: 'Funil de aquisição',  icon: '◐' },
]

export default function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="w-56 min-h-screen bg-white border-r border-gray-100 flex flex-col py-6 px-4">
      {/* Logo / nome do sistema */}
      <div className="mb-8 px-2">
        <p className="text-xs text-gray-400 uppercase tracking-widest">BI Aquisição</p>
        <p className="text-sm font-medium text-gray-700 mt-1">Painel de métricas</p>
      </div>

      {/* Links de navegação */}
      <nav className="flex flex-col gap-1">
        {links.map(link => {
          const active = pathname === link.href
          return (
            <Link
              key={link.href}
              href={link.href}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors
                ${active
                  ? 'bg-blue-50 text-blue-700 font-medium'
                  : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
                }`}
            >
              <span className="text-base">{link.icon}</span>
              {link.label}
            </Link>
          )
        })}
      </nav>

      {/* Rodapé da sidebar */}
      <div className="mt-auto px-2">
        <p className="text-xs text-gray-300">Dados sincronizados</p>
        <p className="text-xs text-gray-400 font-medium">a cada 6 horas</p>
      </div>
    </aside>
  )
}
