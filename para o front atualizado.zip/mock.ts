/**
 * Dados simulados para desenvolvimento local.
 * Substitua as chamadas de api.ts pelos dados reais quando o backend estiver pronto.
 */

import type { KPIs, CustoCampanha, CustoDisparo, Vendedor, EtapaFunil } from '@/types'

export const mockKPIs: KPIs = {
  cac_medio: 142,
  cpl_medio: 38,
  total_investido: 28000,
  total_clientes: 197,
  total_leads: 1240,
  taxa_conversao_geral: 15.9,
}

export const mockCampanhas: CustoCampanha[] = [
  { campanha_id: '1', campanha_nome: 'Prospecção Q3', data: '2024-07-01', gasto: 8400, impressoes: 210000, cliques: 4200, leads: 310, cpc: 2.0, cpm: 40 },
  { campanha_id: '2', campanha_nome: 'Remarketing',   data: '2024-07-01', gasto: 6200, impressoes: 155000, cliques: 3800, leads: 240, cpc: 1.63, cpm: 40 },
  { campanha_id: '3', campanha_nome: 'Lead magnet',   data: '2024-07-01', gasto: 5100, impressoes: 127000, cliques: 2900, leads: 198, cpc: 1.76, cpm: 40 },
  { campanha_id: '4', campanha_nome: 'Branding',      data: '2024-07-01', gasto: 3800, impressoes: 300000, cliques: 1200, leads: 52,  cpc: 3.17, cpm: 12.7 },
  { campanha_id: '5', campanha_nome: 'Black Friday',  data: '2024-07-01', gasto: 4900, impressoes: 180000, cliques: 3600, leads: 440, cpc: 1.36, cpm: 27.2 },
]

export const mockDisparos: CustoDisparo[] = [
  { categoria: 'Marketing',    volume: 12400, custo_total: 1860, custo_medio: 0.15 },
  { categoria: 'Utility',      volume: 8700,  custo_total: 522,  custo_medio: 0.06 },
  { categoria: 'Autenticação', volume: 3200,  custo_total: 96,   custo_medio: 0.03 },
  { categoria: 'Serviço',      volume: 1800,  custo_total: 36,   custo_medio: 0.02 },
]

export const mockVendedores: Vendedor[] = [
  { id: '1', nome: 'Ana Lima',      leads_atendidos: 148, vendas_fechadas: 50, taxa_conversao: 34, ticket_medio: 2100, cac: 130 },
  { id: '2', nome: 'Carlos Souza',  leads_atendidos: 132, vendas_fechadas: 38, taxa_conversao: 29, ticket_medio: 1750, cac: 148 },
  { id: '3', nome: 'Fernanda Rios', leads_atendidos: 125, vendas_fechadas: 34, taxa_conversao: 27, ticket_medio: 1900, cac: 155 },
  { id: '4', nome: 'Lucas Melo',    leads_atendidos: 118, vendas_fechadas: 28, taxa_conversao: 24, ticket_medio: 1620, cac: 163 },
  { id: '5', nome: 'Patrícia Neto', leads_atendidos: 110, vendas_fechadas: 25, taxa_conversao: 23, ticket_medio: 1480, cac: 170 },
  { id: '6', nome: 'Rafael Dias',   leads_atendidos: 105, vendas_fechadas: 22, taxa_conversao: 21, ticket_medio: 1390, cac: 182 },
]

export const mockFunil: EtapaFunil[] = [
  { etapa: 'Leads gerados',  quantidade: 1240 },
  { etapa: 'Qualificados',   quantidade: 744,  taxa_conversao: 60 },
  { etapa: 'Em proposta',    quantidade: 372,  taxa_conversao: 50 },
  { etapa: 'Fechados',       quantidade: 197,  taxa_conversao: 53 },
]

export const mockLeadsPorCanal = [
  { canal: 'Meta Ads',      leads: 520, cor: '#2a78d6' },
  { canal: 'WhatsApp API',  leads: 310, cor: '#1baf7a' },
  { canal: 'Indicação',     leads: 198, cor: '#eda100' },
  { canal: 'Orgânico',      leads: 152, cor: '#6250d6' },
  { canal: 'Outros',        leads: 60,  cor: '#898781' },
]
