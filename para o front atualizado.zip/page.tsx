// app/page.tsx
// Página inicial — localhost:3000/
// Mostra os KPIs gerais de todos os canais.
//
// ➡ PARA COMEÇAR A MEXER: edite os dados em src/lib/mock.ts
// ➡ PARA CONECTAR O BACKEND: substitua mockKPIs por: const data = await getKPIs()

import KpiCard from '@/components/ui/KpiCard'
import { mockKPIs, mockLeadsPorCanal } from '@/lib/mock'

export default function HomePage() {
  const kpis = mockKPIs   // 👈 troque por getKPIs() quando o backend estiver pronto

  return (
    <div>
      {/* Cabeçalho da página */}
      <div className="mb-8">
        <h1 className="text-xl font-medium text-gray-900">Visão geral</h1>
        <p className="text-sm text-gray-400 mt-1">Métricas consolidadas de todos os canais</p>
      </div>

      {/* KPIs principais */}
      {/* ➡ EDITE AQUI: adicione ou remova cards conforme precisar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <KpiCard
          label="CAC Médio"
          value={`R$${kpis.cac_medio}`}
          delta="▲ 8%"
          trend="down"
          hint="vs mês ant."
        />
        <KpiCard
          label="CPL"
          value={`R$${kpis.cpl_medio}`}
          delta="▼ 5%"
          trend="up"
          hint="vs mês ant."
        />
        <KpiCard
          label="Total Investido"
          value={`R$${(kpis.total_investido / 1000).toFixed(0)}k`}
          delta="▼ 3%"
          trend="up"
          hint="vs mês ant."
        />
        <KpiCard
          label="Clientes"
          value={String(kpis.total_clientes)}
          delta="▲ 12%"
          trend="up"
          hint="vs mês ant."
        />
      </div>

      {/* Segunda linha de KPIs */}
      <div className="grid grid-cols-2 gap-4 mb-8 max-w-sm">
        <KpiCard
          label="Total de Leads"
          value={kpis.total_leads.toLocaleString('pt-BR')}
        />
        <KpiCard
          label="Conversão Geral"
          value={`${kpis.taxa_conversao_geral}%`}
        />
      </div>

      {/* Leads por canal — tabela simples */}
      {/* ➡ EDITE AQUI: esse bloco vira um gráfico quando instalar o Recharts */}
      <div className="card max-w-md">
        <p className="section-title">Leads por canal</p>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-xs text-gray-400 border-b border-gray-100">
              <th className="text-left py-2 font-medium">Canal</th>
              <th className="text-right py-2 font-medium">Leads</th>
              <th className="text-right py-2 font-medium">%</th>
            </tr>
          </thead>
          <tbody>
            {mockLeadsPorCanal.map(item => {
              const total = mockLeadsPorCanal.reduce((a, b) => a + b.leads, 0)
              const pct = Math.round((item.leads / total) * 100)
              return (
                <tr key={item.canal} className="border-b border-gray-50 last:border-0">
                  <td className="py-2 flex items-center gap-2">
                    <span
                      className="w-2 h-2 rounded-full inline-block"
                      style={{ background: item.cor }}
                    />
                    {item.canal}
                  </td>
                  <td className="py-2 text-right text-gray-500">{item.leads}</td>
                  <td className="py-2 text-right font-medium">{pct}%</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
