export interface MetricaCAC {
  periodo: string
  canal: string
  total_investido: number
  total_clientes: number
  leads_gerados: number
  cac: number | null
  cpl: number | null
  taxa_conversao: number | null
}

export interface CustoCampanha {
  campanha_id: string
  campanha_nome: string
  data: string
  gasto: number
  impressoes: number
  cliques: number
  leads: number
  cpc: number
  cpm: number
}

export interface CustoDisparo {
  categoria: string
  volume: number
  custo_total: number
  custo_medio: number
}

export interface Vendedor {
  id: string
  nome: string
  leads_atendidos: number
  vendas_fechadas: number
  taxa_conversao: number
  ticket_medio: number
  cac: number
}

export interface EtapaFunil {
  etapa: string
  quantidade: number
  taxa_conversao?: number
}

export interface FiltrosPeriodo {
  inicio: string
  fim: string
  canal?: string
}

export interface KPIs {
  cac_medio: number
  cpl_medio: number
  total_investido: number
  total_clientes: number
  total_leads: number
  taxa_conversao_geral: number
}
